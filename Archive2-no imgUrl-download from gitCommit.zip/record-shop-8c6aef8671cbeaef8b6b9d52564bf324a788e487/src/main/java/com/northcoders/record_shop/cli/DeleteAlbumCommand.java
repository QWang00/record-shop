package com.northcoders.record_shop.cli;

public class DeleteAlbumCommand {
}
