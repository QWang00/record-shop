package com.northcoders.record_shop.cli;

public interface Command {
}
